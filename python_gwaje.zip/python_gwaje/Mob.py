from tkinter import *
from PIL import Image, ImageTk
import winsound     #pygame이 설치가 안되어서 부득이하게 비프음으로 소리를 표현했습니다. 죄송합니다.

class Plane :   #플레이어 비행기
    def __init__(self, window, canvas) :
        self.window = window
        self.canvas = canvas
        self.hearts = 3
        self.image = PhotoImage(file = "Image/plane.png")
        self.PlaneImage = canvas.create_image(960, 750, image = self.image, anchor = CENTER)

    def attacked(self) :
        self.hearts -= 1
        print(f"플레이어 공격받음, 남은 기회 : {self.hearts}")
        if self.hearts == 0 :
            self.canvas.delete(self.PlaneImage)

    def move(self, keys) :
        print("Plane : 키 전달 받음")
        if self.PlaneImage != None :
            position = self.canvas.coords(self.PlaneImage)
        
        if 37 in keys or 65 in keys :
            if position[0] >= 0 :
                self.canvas.move(self.PlaneImage, -10, 0)
        elif 39 in keys or 68 in keys :
            if position[0] <= 960 :
                self.canvas.move(self.PlaneImage, 10, 0)
        else :
            pass
            


class MissileP : #비행기에서 나오는 미사일
    def __init__(self, canvas, positionX, positionY) :
        self.canvas = canvas

        self.image = Image.open("Image/Missile.png")
        self.Image = ImageTk.PhotoImage(self.image)
        self.MissileImage = canvas.create_image(positionX, positionY, image = self.Image, anchor = CENTER)
        winsound.Beep(frequency = 1000, duration = 100)

    def move(self) :
        
        self.position = self.canvas.coords(self.MissileImage) #위치

        while self.position[1] > 0 :    #화면 내에 있으면
            self.canvas.move(self.MissileImage, 0, -15) #움직이고
            self.position = self.canvas.coords(self.MissileImage)   #좌표 구해서
            #print(f"미사일 이동{self.position[0]},{self.position[1]}")
            yield self.position #잠시 전달

        self.canvas.delete(self.MissileImage) #화면 밖에 있으면 사라지도록
        print("미사일 삭제")


class Mob1 :
    def __init__(self, canvas, x, y) :
        self.score = 10
        self.x1 = x - 32
        self.x2 = x + 32
        self.y1 = y - 24
        self.y2 = y + 24

        self.image = Image.open("Image/mob1.png")
        self.Image = ImageTk.PhotoImage(self.image.rotate(180))
        self.mob1Image = canvas.create_image(x, y, image = self.Image, anchor = CENTER)

    def attacked(self) :
        winsound.Beep(frequency = 300, duration = 500)
        return self.score


class Mob2 :
    def __init__(self, canvas, x, y) :
        self.score = 25
        self.x1 = x - 32
        self.x2 = x + 32
        self.y1 = y - 24
        self.y2 = y + 24

        self.image = Image.open("Image/mob2.png")
        self.Image = ImageTk.PhotoImage(self.image.rotate(180))
        self.mob2Image = canvas.create_image(x, y, image = self.Image, anchor = CENTER)

    def attacked(self) :
        winsound.Beep(frequency = 300, duration = 500)
        return self.score


class Mob3 :
    def __init__(self, canvas, x, y) :
        self.score = 50
        self.x1 = x - 32
        self.x2 = x + 32
        self.y1 = y - 24
        self.y2 = y + 24

        self.image = Image.open("Image/mob3.png")
        self.Image = ImageTk.PhotoImage(self.image.rotate(180))
        self.mob3Image = canvas.create_image(x, y, image = self.Image, anchor = CENTER)

    def attacked(self) :
        winsound.Beep(frequency = 300, duration = 500)
        return self.score