from tkinter import *

class MainScrn :
    def __init__(self, window) :

        # 전달받은 윈도우로 캔버스 붙임
        self.menu = Canvas(window, bg="white", width = 1920, height = 1080)
        self.menu.create_text(960,625, font = "Times 50 italic bold", text = "Play")
        self.menu.create_text(960,750, font = "Times 50 italic bold", text = "Exit")

        self.menu_idx = 0 #시작 - 0, 종료 - 1
        self.selection = self.menu.create_text(850, 625, font = "Times 50 italic bold", text = ">>")


    def pack(self) :
        self.menu.pack(expand = True, fill = BOTH)
        print("menu : 캔버스 pack\n")

    def unpack(self) :
        self.menu.pack_forget()
        print("menu : 캔버스 unpack")

    def destroy(self) :
        self.menu.destroy()
        print("menu : 캔버스 destroy")


    def keyPrss(self, keycode) :
        print("menu : 키 관리자로부터 키 입력 전달 성공")
        
        # up key or down key
        if keycode == 38 or keycode == 40 :
            if self.menu_idx > 0 :
                self.menu.coords(self.selection, 850, 625)
                self.menu_idx -= 1
                print("menu : 선택 변경 >> Play\n")
                return 0
            elif self.menu_idx < 1 :
                self.menu.coords(self.selection, 850, 750)
                self.menu_idx += 1
                print("menu : 선택 변경 >> Exit\n")
                return 0
        elif keycode == 13 :
            if self.menu_idx == 0 : # Play에 엔터면 1 반환
                return 1

            elif self.menu_idx == 1 : # Exit에 엔터면 -1 반환
                return -1
        elif keycode == 27 : # Esc면 -1 반환
            return -1
        #이외 다른 키 입력 시
        else :
            print("menu : 선택 변경 >> 없음\n")
            return 0