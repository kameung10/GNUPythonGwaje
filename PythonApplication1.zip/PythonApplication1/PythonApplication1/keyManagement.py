from tkinter import *
import MainScreen
import Game

#키 입력을 각 화면에 맞게 전달
class keyManagement :
    def __init__ (self, window) :
        self.window = window
        self.ScrnNum = 0 #0 >> menu

        self.menuScrn = MainScreen.MainScrn(self.window)
        self.menuScrn.pack()    #기본적으로 메뉴화면 생성
        

    #화면 변경
    def ScrnChange(self) :
        if self.ScrnNum == 0 : # 게임 >> 메뉴 이동
            self.gameScrn.destroy()
            print("keyManager : 캔버스 변경, menu")
            self.menuScrn.pack()

        elif self.ScrnNum == 1 : # 메뉴 >> 게임 이동
            self.menuScrn.unpack()
            self.gameScrn = Game.inGame(self.window)
            print("keyManager : 캔버스 변경, inGame")
            self.gameScrn.pack()


    def keyPrss(self, keycode, keys) :
        print("keyManager : 키 입력 전달 받음")

        if self.ScrnNum == 0 :
            self.ScrnNum = self.menuScrn.keyPrss(keycode) # 메뉴화면일 때, 키 이벤트 넘기기
            
            if self.ScrnNum == -1 : # 반환값이 -1이면 그대로 넘겨서 윈도우창 삭제
                return self.ScrnNum
            elif self.ScrnNum == 1 : # 반환값이 1이면 화면 변경
                self.ScrnChange()

        elif self.ScrnNum == 1:
            self.ScrnNum = self.gameScrn.keyPrss(keycode, keys) # 게임화면일 때, 키 이벤트 넘기기

            if self.ScrnNum == 0 : # 반환값이 0이면 화면 변경
                self.ScrnChange()