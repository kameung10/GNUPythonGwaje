from tkinter import *
import keyManagement

# 화면
class WinScrn :
    def __init__(self) :

        #윈도우 창 생성
        self.window = Tk()
        self.window.title("ㅇㅇ")
        self.window.geometry("1920x1080")
        self.window.protocol("WM_DELETE_WINDOW", self.close)

        self.keys = set()
        self.window.bind("<KeyPress>", self.keyPressHandler)
        self.window.bind("<KeyRelease>", self.keyReleaseHandler)

        self.window.bind("<Button-1>", self.MouseClickEvent)
        self.window.bind("<Double-1>", self.MouseDoubleClickEvent)
        self.window.bind("<B1-Motion>", self.MouseMotionEvent)

        print("윈도우창 생성")

        #키 입력 관리자 생성
        self.keyManager = keyManagement.keyManagement(self.window)            
        print("키 관리자 생성\n")

        
        while True :
            try :
                pass
            except TclError :
                return

            self.window.after(30)
            self.window.update()


    def close(self) :
        self.window.destroy()
        print("윈도우창 삭제")


    #키보드, 마우스 입력 감지 함수
    def keyPressHandler(self, event) :
        self.keys.add(event.keycode)
        print(f"키 입력 : {self.keys}")
        clos = self.keyManager.keyPrss(event.keycode, self.keys) # 누른 자판과 누른 자판들의 항목을 키관리자로 전달
        

        if clos == -1 : # 반환값이 -1이면 윈도우 닫기
            self.close()

    def keyReleaseHandler(self, event) :
        self.keys.remove(event.keycode)

    def MouseClickEvent(self, event) :
        print(f"클릭 : {event.x}, {event.y}")

    def MouseDoubleClickEvent(self, event) :
        print("더블클릭")

    def MouseMotionEvent(self, event) :
        print(f"마우스 이동 : {event.x}, {event.y}")


if __name__ == '__main__' :
    WinScrn()