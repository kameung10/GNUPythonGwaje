from tkinter import *
import Mob

class inGame :
    def __init__(self, window) :
        self.window = window

        #배경 생성, 이동
        self.gameCvs = Canvas(window, bg = "gray", width = 1920, height = 1080)
        self.image = PhotoImage(file = "Image/BG_Image.gif")
        
        self.BGImage = self.gameCvs.create_image(0, 0, image = self.image, anchor = NW)


        #점수 생성
        self.score = 0
        self.scoreText = f"SCORE : {self.score}"
        self.dsply_scre = self.gameCvs.create_text(1200, 50, font = "Times 50 italic bold", text = self.scoreText, fill = "blue")

        #플레이어, 몹 생성
        self.player = Mob.Plane(self.window, self.gameCvs)
        self.mob1 = [[None]*6 for _ in range(2)]    #6개씩 두줄
        self.mob2 = [[None]*6 for _ in range(2)]    #6개씩 두줄
        self.mob3 = [[None]*6]  #6개 한줄

        self.display()  #객체 생성


    def pack(self) :
        self.gameCvs.pack(expand = True)
        print("inGame : 캔버스 pack\n")

    def unpack(self) :
        self.gameCvs.pack_forget()
        print("inGame : 캔버스 unpack")

    def destroy(self) :
        self.gameCvs.destroy()
        print("inGame : 캔버스 destroy")


    def keyPrss(self, keycode, keys) :
        if keycode == 27 :
            return 0

        elif keycode == 32 :  # 스페이스 누르면
            self.playerPosition = self.gameCvs.coords(self.player.PlaneImage)   #플레이어 위치 구해서
            #print(self.playerPosition)

            self.Missile = Mob.MissileP(self.gameCvs, self.playerPosition[0], self.playerPosition[1])   #미사일 생성될 좌표로 제공

            self.missileGenerator = self.Missile.move()
            self.isAttacked()

            return 1
        
        elif keycode == 37 or keycode == 39 or keycode == 65 or keycode == 68 : #왼화살표, 오른 화살표, a, d 입력 시
            self.player.move(keys)                  # 캐릭터 옮기기
            return 1

        else :
            return 1


    def isAttacked(self) :
        try :
            self.missilePosition = next(self.missileGenerator)  #미사일 객체의 돠표 받기
            missileX1 = self.missilePosition[0] - 2
            missileX2 = self.missilePosition[0] + 2
            missileY1 = self.missilePosition[1] - 12
            missileY2 = self.missilePosition[1] - 12

            for a in [0, 1] :
                for b in range(0, 6, 1) :
                    if self.mob1[a][b] is not None :
                        if missileX1 > self.mob1[a][b].x1 and missileX2 < self.mob1[a][b].x2 and missileY1 > self.mob1[a][b].y1 and missileY2 < self.mob1[a][b].y2 :    #몹1에 맞으면
                            self.gameCvs.delete(self.Missile.MissileImage)
                            self.Missile = None
                            
                            self.score += self.mob1[a][b].attacked()
                            self.gameCvs.delete(self.mob1[a][b].mob1Image)
                            self.mob1[a][b] = None
                            
                            self.scoreText = f"SCORE : {self.score}"
                            self.gameCvs.delete(self.dsply_scre)
                            self.dsply_scre = self.gameCvs.create_text(1200, 50, font = "Times 50 italic bold", text = self.scoreText, fill = "blue")
                            return

                    if self.mob2[a][b] is not None :
                        if missileX1 > self.mob2[a][b].x1 and missileX2 < self.mob2[a][b].x2 and missileY1 > self.mob2[a][b].y1 and missileY2 < self.mob2[a][b].y2 :    #몹2에 맞으면
                            self.gameCvs.delete(self.Missile.MissileImage)
                            self.Missile = None
                            
                            self.score += self.mob2[a][b].attacked()
                            self.gameCvs.delete(self.mob2[a][b])
                            self.mob2[a][b] = None
                            
                            self.scoreText = f"SCORE : {self.score}"
                            self.gameCvs.delete(self.dsply_scre)
                            self.dsply_scre = self.gameCvs.create_text(1200, 50, font = "Times 50 italic bold", text = self.scoreText, fill = "blue")
                            return

            for b in range(0, 6, 1) :
                if self.mob3[0][b] is not None :
                    if missileX1 > self.mob3[0][b].x1 and missileX2 < self.mob3[0][b].x2 and missileY1 > self.mob3[0][b].y1 and missileY2 < self.mob3[0][b].y2 :    #몹3에 맞으면ㄴ
                        self.gameCvs.delete(self.Missile.MissileImage)
                        self.Missile = None
                        
                        self.score += self.mob3[0][b].attacked()
                        self.gameCvs.delete(self.mob3[0][b])
                        self.mob3[0][b] = None
                        
                        self.scoreText = f"SCORE : {self.score}"
                        self.gameCvs.delete(self.dsply_scre)
                        self.dsply_scre = self.gameCvs.create_text(1200, 50, font = "Times 50 italic bold", text = self.scoreText, fill = "blue")
                        return

        except StopIteration :
            self.Missile = None
            pass

        self.none1 = 1
        self.none2 = 1
        self.none3 = 1
        for a in [0, 1] :
            for b in range(0, 6, 1) :
                if self.mob1[a][b] is not None :
                    self.none1 = 0
                if self.mob2[a][b] is not None :
                    self.none2 = 0
        for b in range(0, 6, 1) :
            if self.mob3[0][b] is not None :
                self.none3 = 0
        if self.none1 == 1 and self.none2 == 1 and self.none3 == 1 : #화면 상의 몹들이 전부 사라지면 다시 생성
            self.none1 = 0
            self.none2 = 0
            self.none3 = 0
            self.display()

        if self.Missile is not None :
            self.window.after(30, self.isAttacked)


    def display(self) : #몹 생성
        a = 0
        for y in [350, 425] :
            b = 0
            for x in range(80, 900, 160) :
                self.mob1[a][b] = Mob.Mob1(self.gameCvs, x, y)
                b += 1
            a += 1

        a = 0
        for y in [200, 275] :
            b = 0
            for x in range(80, 900, 160) :
                self.mob2[a][b] = Mob.Mob2(self.gameCvs, x, y)
                b += 1
            a += 1

        a = 0
        for y in [125] :
            b = 0
            for x in range(80, 900, 160) :
                self.mob3[a][b] = Mob.Mob3(self.gameCvs, x, y)
                b += 1
            a += 1